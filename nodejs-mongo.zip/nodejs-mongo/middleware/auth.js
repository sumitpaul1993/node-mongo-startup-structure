const jwt = require('jsonwebtoken');
const { success, error401 } = require('../function/response')
const { jwtVerify } = require('../function/common')
const config = require('../config')

exports.apiAuth = async (req,res,next) => {
    const header = req.header('x-access-token');
    if(!header) {
        error401(res)
    }else if(header != config.API_SECRET_TOKEN) {
        error401(res)
    }else {
        next()
    }
} 

exports.auth = async (req, res, next) =>  {
    const header = req.header('Authorization');
    if(!header) {
        error401(res)
    }else if (header.split(' ')[0] != "Bearer") {
        error401(res)
    }else {
        try {
            const decoded = await jwtVerify(header.split(' ')[1]);
            req.auth = decoded
            next()            
        } catch (e) {
            console.log("token decript err : ", e)
        }
    }
}
