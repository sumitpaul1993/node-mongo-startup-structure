const env = require('dotenv')
const config = {}

// Environment Variables
env.config()


config.PORT = process.env.PORT
config.MONGO_SRV = process.env.MONGO_SRV
config.BASE_URL = process.env.BASE_URL
config.JWT_PRIVATE_KEY = process.env.JWT_PRIVATE_KEY
config.API_SECRET_TOKEN = process.env.API_SECRET_TOKEN


module.exports = config