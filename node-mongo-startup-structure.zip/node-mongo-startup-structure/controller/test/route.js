const express = require('express')
const router = express.Router()
const models = global.models;
const mongoose = require('mongoose');
const { auth } = require('../../middleware/auth')
const { success } = require('../../function/response')

router.get('/', auth, async (req, res) => {
    try {
        // models.test.create({test: "amit new"}, ( data ) => {
        //     success(res, 'Create test collection', data)
        // })
        
        console.log(models)
    } catch (e) {
        console.log(e)
    }

})

module.exports = router