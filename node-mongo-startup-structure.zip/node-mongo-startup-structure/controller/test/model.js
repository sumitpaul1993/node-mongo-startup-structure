const mongoose = require('mongoose');

// module.exports = async () => {

const test = mongoose.model('test', function () {
    var s = new mongoose.Schema({
        test: {
            type: String
        },

    }, {
        timestamps: true
    });

    s.statics.create = function (data, callback) {
        new test(data).save(function (err, response_data) {
            if (err) {
                callback(err)
            }
            if (!err) {
                callback(response_data);
            }
        })
    };



    return s
}());
global.models['test'] = test;
// }

// module.exports = test