const env = require('dotenv')
const config = {}

// Environment Variables
env.config()


config.PORT = process.env.PORT
config.MONGO_SRV = process.env.MONGO_SRV
config.BASE_URL = process.env.BASE_URL


module.exports = config