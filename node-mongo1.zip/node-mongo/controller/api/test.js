const express = require('express')
const router = express.Router()
const models = global.models;
const mongoose = require('mongoose');
const { auth, apiAuth } = require('../../middleware/auth')
const { success } = require('../../function/response')
const { generateJwtToken } = require('../../function/common')

exports.test = async (req, res) => {
    try {
        // models.test.create({test: "amit new"}, ( data ) => {
        //     success(res, 'Create test collection', data)
        // }) 
        
        models.test.fetchAll({}, ( err, data ) => {
            success(res, 'Create test collection', data)
        }) 
        // console.log(models)
        // success(res,'hello')
    } catch (e) {
        console.log(e)
    }

}