const jwt = require('jsonwebtoken');
const config = require('../config')

const generateJwtToken = (data) => {
    try {
        return jwt.sign(data, config.JWT_PRIVATE_KEY, {expiresIn: 0});
    } catch (e) {
        console.log('Token generate err : ', e)
    }
}

const jwtVerify = async (token) => {
    return new Promise((resolve, reject) => {
        jwt.verify(token, config.JWT_PRIVATE_KEY, (err, decode) => {
            if (err) {
                reject(err)
            }
            resolve(decode)
        })
    });
}

module.exports = {
    generateJwtToken,
    jwtVerify
}